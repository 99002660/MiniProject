#include "customer.h"
#include "account.h"
Customer::Customer(){}
//Customer::Customer(char sname):name(sname[]){}}
void Customer::create_account()
{
	cout<<"\nEnter The account No. :";
	cin>>acno;
	cout<<"\n\nEnter The Name of The account Holder : ";
	cin.ignore();
	cin.getline(name,50);
	cout<<"\nEnter Type of The account (C/S) : ";
	cin>>type;
	type=toupper(type);
	cout<<"\nEnter The Initial amount(>=500 for Saving and >=1000 for current ) : ";
	cin>>deposit;
	cout<<"\n\n\nAccount Created..";
}

void Customer::show_account() const
{
	cout<<"\nAccount No. : "<<acno;
	cout<<"\nAccount Holder Name : ";
	cout<<name;
	cout<<"\nType of Account : "<<type;
	cout<<"\nBalance amount : "<<deposit;
}


// void Customer::modify()
// {
// 	cout<<"\nAccount No. : "<<acno;
// 	cout<<"\nModify Account Holder Name : ";
// 	cin.ignore();
// 	cin.getline(name,50);
// 	cout<<"\nModify Type of Account : ";
// 	cin>>type;
// 	type=toupper(type);
// 	cout<<"\nModify Balance amount : ";
// 	cin>>deposit;
// }

	
void Customer::dep(int x)
{
	deposit+=x;
}



// T Customer <T>:: draw(int x)
// {
// 	deposit-=x;
// }
void Customer::draw(int x)
{
	deposit-=x;
}
	
void Customer::report() const
{
	cout<<acno<<setw(10)<<" "<<name<<setw(10)<<" "<<type<<setw(6)<<deposit<<endl;
}

	
int Customer::retacno() const
{
	return acno;
}

int Customer::retdeposit() const
{
	return deposit;
}

char Customer::rettype() const
{
	return type;
}

