#ifndef __ACCOUNT_H
#define __ACCOUNT_H

#include "customer.h"
class Account : public Customer //Inheritance
{
    //Account ac;
    int num1;
    string line;
   // list <int> list1;
    public:
    Account(): num1(8){}    
   // Account();
    void write_account();	//function to write record in binary file
    void display_sp(int);	//function to display account details given by user
    void modify_account(int);	//function to modify record of file
    void delete_account(int);	//function to delete record of file
    void display_all();		//function to display all account details
    void deposit_withdraw(int, int); // function to desposit/withdraw amount for given account
    void intro();	//introductory screen function
    void operatorOver(); //function to display operator overloading
    void operator ++();  // operator ++ 
    void operator --(); 
};
#endif
