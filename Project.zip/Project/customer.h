#ifndef __CUSTOMER_H
#define __CUSTOMER_H
#include<iostream>
#include<fstream>
#include<cctype>
#include<iomanip>
using namespace std;


class Customer
{
	int acno;
	char name[50];
	int deposit;
	char type;
public:
	
 	Customer();
	Customer(char);
	void create_account();	//function to get data from user
	void show_account() const;	//function to show data on screen
	virtual void modify();	//function to add new data		// VIRTUAL FUNCTION
	void dep(int);	//function to accept amount and add to balance amount
	void draw(int);	//function to accept amount and subtract from balance amount
	void report() const;	//function to show data in tabular format
	int retacno() const;	//function to return account number
	int retdeposit() const;	//function to return balance amount
	char rettype() const;	//function to return type of account
	//virtual void modify_account(int);
};        
#endif